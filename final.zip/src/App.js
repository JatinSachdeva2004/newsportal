import React from "react";

import News from "./components/news/news";

const App = () => {
  return (
    <>
      <News />
    </>
  );
};

export default App;
